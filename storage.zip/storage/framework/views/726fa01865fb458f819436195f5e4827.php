<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['maxWidth' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('lg')]); ?>
    <div class="w-full">
        <!-- Header -->
        <div class="mb-6">
            <h2 class="text-2xl font-black text-white mb-1 tracking-tighter uppercase">Corporate Registry</h2>
            <p class="text-slate-300 font-medium text-xs">Register enterprise node for tier-1 access.</p> <!-- Brightened Description -->
        </div>

        <form method="POST" action="<?php echo e(route('corporate.register.store')); ?>" class="space-y-4">
            <?php echo csrf_field(); ?>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <!-- Company Name -->
                <div>
                    <label for="name" class="label-text">Enterprise Name</label>
                    <div class="relative group">
                        <i class="fa-solid fa-building input-icon"></i>
                        <input id="name" class="input-dark" type="text" name="name" :value="old('name')" required autofocus placeholder="Legal Identity" />
                    </div>
                    <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('name'),'class' => 'mt-1']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('name')),'class' => 'mt-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                </div>

                <!-- NTN Number -->
                <div>
                    <label for="ntn_number" class="label-text">NTN Registry</label>
                    <div class="relative group">
                        <i class="fa-solid fa-file-invoice input-icon"></i>
                        <input id="ntn_number" class="input-dark" type="text" name="ntn_number" :value="old('ntn_number')" required placeholder="7-Digit NTN" />
                    </div>
                </div>
            </div>

            <!-- Email Address -->
            <div>
                <label for="email" class="label-text">Operational Email</label>
                <div class="relative group">
                    <i class="fa-solid fa-envelope input-icon"></i>
                    <input id="email" class="input-dark" type="email" name="email" :value="old('email')" required placeholder="ops@enterprise.com" />
                </div>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <!-- Password -->
                <div>
                    <label for="password" class="label-text">Security Pin</label>
                    <div class="relative group">
                        <i class="fa-solid fa-lock input-icon"></i>
                        <input id="password" class="input-dark" type="password" name="password" required placeholder="••••••••" />
                    </div>
                </div>

                <!-- Confirm Password -->
                <div>
                    <label for="password_confirmation" class="label-text">Verify Pin</label>
                    <div class="relative group">
                        <i class="fa-solid fa-shield-halved input-icon"></i>
                        <input id="password_confirmation" class="input-dark" type="password" name="password_confirmation" required placeholder="••••••••" />
                    </div>
                </div>
            </div>

            <div class="pt-2">
                <button type="submit" class="btn-primary">
                    Initialize Enterprise
                </button>
            </div>

            <div class="pt-4 border-t border-white/5 text-center">
                <a href="<?php echo e(route('login')); ?>" class="text-[10px] font-black text-white hover:text-[#ED1C24] uppercase tracking-widest transition-all">
                    Already Authorized? Login to Portal
                </a>
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH /home/eventy/public_html/resources/views/auth/register-corporate.blade.php ENDPATH**/ ?>