<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['maxWidth' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('md')]); ?>
    <div class="w-full">
        <!-- Header -->
        <div class="mb-6">
            <h2 class="text-2xl font-black text-white mb-1 tracking-tighter uppercase">Client Signup</h2>
            <p class="text-slate-400 font-medium text-xs opacity-70">Join Pakistan's premier event network.</p>
        </div>

        <form method="POST" action="<?php echo e(route('register')); ?>" class="space-y-4">
            <?php echo csrf_field(); ?>

            <!-- Name -->
            <div>
                <label for="name" class="label-text">Full Identity</label>
                <div class="relative group">
                    <i class="fa-solid fa-user input-icon"></i>
                    <input id="name" class="input-dark" type="text" name="name" :value="old('name')" required autofocus placeholder="Your Full Name" />
                </div>
            </div>

            <!-- Email Address -->
            <div>
                <label for="email" class="label-text">Digital Handle</label>
                <div class="relative group">
                    <i class="fa-solid fa-envelope input-icon"></i>
                    <input id="email" class="input-dark" type="email" name="email" :value="old('email')" required placeholder="email@example.com" />
                </div>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <!-- Password -->
                <div>
                    <label for="password" class="label-text">Security Pin</label>
                    <div class="relative group">
                        <i class="fa-solid fa-lock input-icon"></i>
                        <input id="password" class="input-dark" type="password" name="password" required placeholder="••••••••" />
                    </div>
                </div>

                <!-- Confirm Password -->
                <div>
                    <label for="password_confirmation" class="label-text">Verify Pin</label>
                    <div class="relative group">
                        <i class="fa-solid fa-shield-halved input-icon"></i>
                        <input id="password_confirmation" class="input-dark" type="password" name="password_confirmation" required placeholder="••••••••" />
                    </div>
                </div>
            </div>

            <div class="pt-2">
                <button type="submit" class="btn-primary" style="background: linear-gradient(to right, #6366f1, #4f46e5); box-shadow: 0 10px 15px -3px rgba(99, 102, 241, 0.2);">
                    Initialize Account
                </button>
            </div>

            <div class="pt-4 border-t border-white/5 text-center">
                <a href="<?php echo e(route('login')); ?>" class="text-[10px] font-black text-white hover:text-indigo-400 uppercase tracking-widest transition-all">
                    Already a Client? Log In
                </a>
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH /home/eventy/public_html/resources/views/auth/register.blade.php ENDPATH**/ ?>