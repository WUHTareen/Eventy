<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <div>
                <h2 class="font-bold text-2xl text-gray-800 leading-tight">
                    <i class="fa-solid fa-shield-halved text-[#0A3A7A] mr-2"></i><?php echo e(__('Admin Control Center')); ?>

                </h2>
                <p class="text-gray-500 text-sm mt-1">Manage users, vendors, and platform settings</p>
            </div>
            <div class="flex items-center gap-3">
                <a href="<?php echo e(route('admin.custom-packages')); ?>" class="flex items-center gap-2 bg-[#0A3A7A] text-white px-4 py-2 rounded-xl border border-[#0A3A7A] hover:bg-[#0D4E9A] transition-colors shadow-lg hover:shadow-xl">
                    <i class="fa-solid fa-layer-group text-yellow-400"></i>
                    <span class="font-bold text-sm">Custom Ensembles</span>
                </a>
                <a href="<?php echo e(route('admin.budget-requests')); ?>" class="flex items-center gap-2 bg-white text-[#0A3A7A] px-4 py-2 rounded-xl border border-[#0A3A7A]/20 hover:bg-slate-50 transition-colors shadow-lg hover:shadow-xl">
                    <i class="fa-solid fa-calculator text-primary-500"></i>
                    <span class="font-bold text-sm">Budget Requests</span>
                </a>
                <a href="/admin/hotels" class="flex items-center gap-2 bg-white text-[#0A3A7A] px-4 py-2 rounded-xl border border-[#0A3A7A]/20 hover:bg-slate-50 transition-colors shadow-lg hover:shadow-xl">
                    <i class="fa-solid fa-hotel text-indigo-500"></i>
                    <span class="font-bold text-sm">Hotels</span>
                </a>
                <a href="/admin/settings" class="flex items-center gap-2 bg-white text-[#0A3A7A] px-4 py-2 rounded-xl border border-[#0A3A7A]/20 hover:bg-slate-50 transition-colors shadow-lg hover:shadow-xl">
                    <i class="fa-solid fa-gear text-gray-500"></i>
                    <span class="font-bold text-sm">Site Settings</span>
                </a>
                <div class="flex items-center gap-2 bg-[#0A3A7A]/5 px-4 py-2 rounded-xl border border-[#0A3A7A]/10">
                    <div class="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                    <span class="text-[#0A3A7A] font-bold text-sm">System Online</span>
                </div>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-8 bg-gradient-to-b from-slate-50 to-white min-h-screen">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            
            <?php if(session('success')): ?>
                <div class="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 text-green-800 px-6 py-4 rounded-2xl relative mb-8 shadow-sm flex items-center">
                    <div class="w-10 h-10 bg-green-100 rounded-xl flex items-center justify-center mr-4">
                        <i class="fa-solid fa-check text-green-600"></i>
                    </div>
                    <span class="font-medium"><?php echo e(session('success')); ?></span>
                </div>
            <?php endif; ?>

            <!-- Stats Overview -->
            <div>
                <div class="transition-opacity duration-500">
                    <?php echo $__env->make('admin.partials.dashboard-stats', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <!-- Recent Clients Section (Live Polling) -->
                <div x-data="{
                    refreshClients() {
                        fetch('<?php echo e(route('admin.dashboard')); ?>', { 
                            method: 'GET',
                            headers: { 'X-Partial': 'clients', 'X-Requested-With': 'XMLHttpRequest' }
                        })
                        .then(response => response.text())
                        .then(html => {
                            $refs.clientsContainer.innerHTML = html;
                        });
                    },
                    init() {
                        setInterval(() => {
                            this.refreshClients();
                        }, 5000);
                    }
                }" x-init="init()">
                    <div x-ref="clientsContainer" class="transition-opacity duration-500">
                        <?php echo $__env->make('admin.partials.recent-clients-table', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                </div>

                <!-- Vendor Verification Section (Live Polling) -->
                <div x-data="{
                    refreshVendors() {
                        fetch('<?php echo e(route('admin.dashboard')); ?>', { 
                            method: 'GET',
                            headers: { 'X-Partial': 'vendors', 'X-Requested-With': 'XMLHttpRequest' }
                        })
                        .then(response => response.text())
                        .then(html => {
                            $refs.vendorsContainer.innerHTML = html;
                        });
                    },
                    init() {
                        setInterval(() => {
                            this.refreshVendors();
                        }, 5000);
                    }
                }" x-init="init()">
                    <div x-ref="vendorsContainer" class="transition-opacity duration-500">
                        <?php echo $__env->make('admin.partials.pending-vendors-table', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                </div>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>


<?php /**PATH /home/eventy/public_html/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>