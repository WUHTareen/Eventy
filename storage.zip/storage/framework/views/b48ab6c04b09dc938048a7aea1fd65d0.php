<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <div>
                <h2 class="font-bold text-2xl text-gray-800"><i class="fa-solid fa-hotel text-[#0A3A7A] mr-2"></i> Hotel Management</h2>
                <p class="text-gray-500 text-sm mt-1">Add, approve, edit and manage all hotels</p>
            </div>
            <div class="flex gap-3">
                <a href="<?php echo e(route('admin.hotels.create')); ?>" class="bg-[#0A3A7A] text-white px-5 py-2.5 rounded-xl font-bold text-sm hover:bg-[#0D4E9A] transition flex items-center gap-2">
                    <i class="fa-solid fa-plus"></i> Add Hotel
                </a>
                <a href="<?php echo e(route('admin.hotels.bookings')); ?>" class="bg-white border border-gray-200 text-gray-700 px-5 py-2.5 rounded-xl font-bold text-sm hover:bg-gray-50 transition flex items-center gap-2">
                    <i class="fa-solid fa-calendar-check"></i> All Bookings
                </a>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-8 bg-slate-50 min-h-screen">
        <div class="max-w-7xl mx-auto px-4">

            <?php if(session('success')): ?>
                <div class="mb-4 p-4 bg-green-50 border border-green-200 rounded-xl text-green-700 font-medium">✓ <?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
                <div class="p-5 border-b">
                    <h3 class="font-bold text-gray-800">All Hotels <span class="text-gray-400 font-normal text-sm">(<?php echo e($hotels->total()); ?> total)</span></h3>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full">
                        <thead class="bg-gray-50 text-xs font-bold text-gray-500 uppercase">
                            <tr>
                                <th class="px-6 py-4 text-left">Hotel</th>
                                <th class="px-6 py-4 text-left">Owner</th>
                                <th class="px-6 py-4 text-left">City</th>
                                <th class="px-6 py-4 text-left">Stars</th>
                                <th class="px-6 py-4 text-left">Rooms</th>
                                <th class="px-6 py-4 text-left">Status</th>
                                <th class="px-6 py-4 text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-50">
                            <?php $__empty_1 = true; $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-slate-50">
                                <td class="px-6 py-4">
                                    <div class="flex items-center gap-3">
                                        <img src="<?php echo e($hotel->getCoverImageUrl()); ?>" class="w-12 h-12 rounded-xl object-cover">
                                        <div>
                                            <p class="font-semibold text-gray-800 text-sm"><?php echo e($hotel->name); ?></p>
                                            <?php if($hotel->is_featured): ?> <span class="text-xs text-yellow-600 font-bold">⭐ Featured</span> <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4 text-sm text-gray-600"><?php echo e($hotel->user->name ?? '-'); ?></td>
                                <td class="px-6 py-4 text-sm text-gray-600"><?php echo e($hotel->city->name ?? '-'); ?></td>
                                <td class="px-6 py-4 text-sm"><?php echo e(str_repeat('⭐', $hotel->star_rating)); ?></td>
                                <td class="px-6 py-4 text-sm font-bold text-indigo-600"><?php echo e($hotel->rooms->count()); ?></td>
                                <td class="px-6 py-4">
                                    <span class="px-3 py-1 rounded-full text-xs font-bold <?php echo e($hotel->status === 'approved' ? 'bg-green-50 text-green-600' : ($hotel->status === 'rejected' ? 'bg-red-50 text-red-600' : 'bg-yellow-50 text-yellow-600')); ?>">
                                        <?php echo e(ucfirst($hotel->status)); ?>

                                    </span>
                                </td>
                                <td class="px-6 py-4 text-right">
                                    <div class="flex justify-end gap-2 flex-wrap">
                                        <a href="<?php echo e(route('admin.hotels.show', $hotel)); ?>" class="bg-blue-50 text-blue-600 hover:bg-blue-100 px-3 py-1.5 rounded-lg text-xs font-bold transition">
                                            <i class="fa-solid fa-eye"></i> View
                                        </a>
                                        <a href="<?php echo e(route('admin.hotels.edit', $hotel)); ?>" class="bg-indigo-50 text-indigo-600 hover:bg-indigo-100 px-3 py-1.5 rounded-lg text-xs font-bold transition">
                                            <i class="fa-solid fa-pen"></i> Edit
                                        </a>
                                        <?php if($hotel->status === 'pending'): ?>
                                        <form action="<?php echo e(route('admin.hotels.approve', $hotel)); ?>" method="POST" class="inline">
                                            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                            <button class="bg-green-50 text-green-600 hover:bg-green-100 px-3 py-1.5 rounded-lg text-xs font-bold">✓ Approve</button>
                                        </form>
                                        <?php endif; ?>
                                        <form action="<?php echo e(route('admin.hotels.featured', $hotel)); ?>" method="POST" class="inline">
                                            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                            <button class="bg-yellow-50 text-yellow-600 hover:bg-yellow-100 px-3 py-1.5 rounded-lg text-xs font-bold">
                                                <?php echo e($hotel->is_featured ? '★ Unfeature' : '☆ Feature'); ?>

                                            </button>
                                        </form>
                                        <form action="<?php echo e(route('admin.hotels.destroy', $hotel)); ?>" method="POST" class="inline" onsubmit="return confirm('Delete this hotel?')">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button class="bg-red-50 text-red-600 hover:bg-red-100 px-3 py-1.5 rounded-lg text-xs font-bold">
                                                <i class="fa-solid fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="7" class="px-6 py-12 text-center text-gray-400">No hotels found. <a href="<?php echo e(route('admin.hotels.create')); ?>" class="text-indigo-600 font-bold">Add one now →</a></td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="p-5 border-t"><?php echo e($hotels->links()); ?></div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/eventy/public_html/resources/views/hotels/admin/index.blade.php ENDPATH**/ ?>