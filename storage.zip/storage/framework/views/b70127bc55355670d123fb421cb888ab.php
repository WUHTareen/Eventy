<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['maxWidth' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('lg')]); ?>
    <div class="w-full">
        <!-- Header -->
        <div class="mb-6">
            <h2 class="text-2xl font-black text-white mb-1 tracking-tighter uppercase">Vendor Registry</h2>
            <p class="text-slate-400 font-medium text-xs opacity-70">Onboard services into the elite network.</p>
        </div>

        <form method="POST" action="<?php echo e(route('vendor.register.store')); ?>" class="space-y-4">
            <?php echo csrf_field(); ?>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <!-- Business Name -->
                <div>
                    <label for="name" class="label-text">Business Identity</label>
                    <div class="relative group">
                        <i class="fa-solid fa-briefcase input-icon"></i>
                        <input id="name" class="input-dark" type="text" name="name" :value="old('name')" required autofocus placeholder="Trading Name" />
                    </div>
                </div>

                <!-- Operating Hub -->
                <div>
                    <label for="city_id" class="label-text">Operating Hub</label>
                    <div class="relative group">
                        <i class="fa-solid fa-location-dot input-icon"></i>
                        <select id="city_id" name="city_id" class="input-dark appearance-none">
                            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($city->id); ?>" class="bg-gray-900"><?php echo e($city->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <!-- Category -->
                <div>
                    <label for="category_id" class="label-text">Service Vertical</label>
                    <div class="relative group">
                        <i class="fa-solid fa-layer-group input-icon"></i>
                        <select id="category_id" name="category_id" class="input-dark appearance-none">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>" class="bg-gray-900"><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <!-- Registry Email -->
                <div>
                    <label for="email" class="label-text">Registry Email</label>
                    <div class="relative group">
                        <i class="fa-solid fa-envelope input-icon"></i>
                        <input id="email" class="input-dark" type="email" name="email" :value="old('email')" required placeholder="vendor@supply.com" />
                    </div>
                </div>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <!-- Password -->
                <div>
                    <label for="password" class="label-text">Access Pin</label>
                    <div class="relative group">
                        <i class="fa-solid fa-lock input-icon"></i>
                        <input id="password" class="input-dark" type="password" name="password" required placeholder="••••••••" />
                    </div>
                </div>

                <!-- Verify PIN -->
                <div>
                    <label for="password_confirmation" class="label-text">Verify Pin</label>
                    <div class="relative group">
                        <i class="fa-solid fa-shield-halved input-icon"></i>
                        <input id="password_confirmation" class="input-dark" type="password" name="password_confirmation" required placeholder="••••••••" />
                    </div>
                </div>
            </div>

            <div class="pt-2">
                <button type="submit" class="btn-primary" style="background: linear-gradient(to right, #06b6d4, #0891b2); box-shadow: 0 10px 15px -3px rgba(6, 182, 212, 0.2);">
                    Register Entity
                </button>
            </div>

            <div class="pt-4 text-center grid grid-cols-2 gap-3 border-t border-white/5">
                <a href="<?php echo e(route('login')); ?>" class="py-2 border border-white/5 rounded-lg text-[9px] font-black text-white hover:text-cyan-400 uppercase tracking-widest transition-all bg-white/[0.01]">Login</a>
                <a href="<?php echo e(route('register')); ?>" class="py-2 border border-white/5 rounded-lg text-[9px] font-black text-white hover:text-indigo-400 uppercase tracking-widest transition-all bg-white/[0.01]">Client Signup</a>
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH /home/eventy/public_html/resources/views/auth/register-vendor.blade.php ENDPATH**/ ?>