<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Eventy')); ?> | Management Console</title>
        <meta name="description" content="Manage your event services and bookings with Eventy's premium management console.">

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=inter:400,500,600,700" rel="stylesheet" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <script src="https://cdn.tailwindcss.com"></script>
        
        <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>

        <style>
            html { font-size: 92%; }
            body { font-family: 'Inter', sans-serif; letter-spacing: -0.01em; }
            [x-cloak] { display: none !important; }
        </style>
        <?php echo $__env->yieldPushContent('styles'); ?>
    </head>
    <body class="font-sans antialiased bg-gray-50">
        <?php echo $__env->make('partials.toast', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div class="min-h-screen">
            <?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <!-- Page Heading -->
            <?php if(isset($header)): ?>
                <header class="bg-white shadow-sm border-b border-gray-100 sticky top-[64px] z-40">
                    <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                        <?php echo e($header); ?>

                    </div>
                </header>
            <?php endif; ?>

            <!-- Page Content -->
            <main>
                <?php echo e($slot); ?>

            </main>
        </div>
        <?php if (isset($component)) { $__componentOriginal8c085ee5e7a39cd0ba199a1f86dfa0b2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c085ee5e7a39cd0ba199a1f86dfa0b2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.back-to-top','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('back-to-top'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c085ee5e7a39cd0ba199a1f86dfa0b2)): ?>
<?php $attributes = $__attributesOriginal8c085ee5e7a39cd0ba199a1f86dfa0b2; ?>
<?php unset($__attributesOriginal8c085ee5e7a39cd0ba199a1f86dfa0b2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c085ee5e7a39cd0ba199a1f86dfa0b2)): ?>
<?php $component = $__componentOriginal8c085ee5e7a39cd0ba199a1f86dfa0b2; ?>
<?php unset($__componentOriginal8c085ee5e7a39cd0ba199a1f86dfa0b2); ?>
<?php endif; ?>
    </body>
</html>


<?php /**PATH /home/eventy/public_html/resources/views/layouts/app.blade.php ENDPATH**/ ?>